                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler 
                                      3 ; Version 4.4.0 #14620 (MINGW32)
                                      4 ;--------------------------------------------------------
                                      5 	.module testpreempt
                                      6 	.optsdcc -mmcs51 --model-small
                                      7 	
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _SemaphoreCreate_PARM_2
                                     12 	.globl _timer0_ISR
                                     13 	.globl __mcs51_genXRAMCLEAR
                                     14 	.globl __mcs51_genXINIT
                                     15 	.globl __mcs51_genRAMCLEAR
                                     16 	.globl __sdcc_gsinit_startup
                                     17 	.globl _main
                                     18 	.globl _Consumer
                                     19 	.globl _Producer
                                     20 	.globl _SemaphoreCreate
                                     21 	.globl _ThreadCreate
                                     22 	.globl _CY
                                     23 	.globl _AC
                                     24 	.globl _F0
                                     25 	.globl _RS1
                                     26 	.globl _RS0
                                     27 	.globl _OV
                                     28 	.globl _F1
                                     29 	.globl _P
                                     30 	.globl _PS
                                     31 	.globl _PT1
                                     32 	.globl _PX1
                                     33 	.globl _PT0
                                     34 	.globl _PX0
                                     35 	.globl _RD
                                     36 	.globl _WR
                                     37 	.globl _T1
                                     38 	.globl _T0
                                     39 	.globl _INT1
                                     40 	.globl _INT0
                                     41 	.globl _TXD
                                     42 	.globl _RXD
                                     43 	.globl _P3_7
                                     44 	.globl _P3_6
                                     45 	.globl _P3_5
                                     46 	.globl _P3_4
                                     47 	.globl _P3_3
                                     48 	.globl _P3_2
                                     49 	.globl _P3_1
                                     50 	.globl _P3_0
                                     51 	.globl _EA
                                     52 	.globl _ES
                                     53 	.globl _ET1
                                     54 	.globl _EX1
                                     55 	.globl _ET0
                                     56 	.globl _EX0
                                     57 	.globl _P2_7
                                     58 	.globl _P2_6
                                     59 	.globl _P2_5
                                     60 	.globl _P2_4
                                     61 	.globl _P2_3
                                     62 	.globl _P2_2
                                     63 	.globl _P2_1
                                     64 	.globl _P2_0
                                     65 	.globl _SM0
                                     66 	.globl _SM1
                                     67 	.globl _SM2
                                     68 	.globl _REN
                                     69 	.globl _TB8
                                     70 	.globl _RB8
                                     71 	.globl _TI
                                     72 	.globl _RI
                                     73 	.globl _P1_7
                                     74 	.globl _P1_6
                                     75 	.globl _P1_5
                                     76 	.globl _P1_4
                                     77 	.globl _P1_3
                                     78 	.globl _P1_2
                                     79 	.globl _P1_1
                                     80 	.globl _P1_0
                                     81 	.globl _TF1
                                     82 	.globl _TR1
                                     83 	.globl _TF0
                                     84 	.globl _TR0
                                     85 	.globl _IE1
                                     86 	.globl _IT1
                                     87 	.globl _IE0
                                     88 	.globl _IT0
                                     89 	.globl _P0_7
                                     90 	.globl _P0_6
                                     91 	.globl _P0_5
                                     92 	.globl _P0_4
                                     93 	.globl _P0_3
                                     94 	.globl _P0_2
                                     95 	.globl _P0_1
                                     96 	.globl _P0_0
                                     97 	.globl _B
                                     98 	.globl _ACC
                                     99 	.globl _PSW
                                    100 	.globl _IP
                                    101 	.globl _P3
                                    102 	.globl _IE
                                    103 	.globl _P2
                                    104 	.globl _SBUF
                                    105 	.globl _SCON
                                    106 	.globl _P1
                                    107 	.globl _TH1
                                    108 	.globl _TH0
                                    109 	.globl _TL1
                                    110 	.globl _TL0
                                    111 	.globl _TMOD
                                    112 	.globl _TCON
                                    113 	.globl _PCON
                                    114 	.globl _DPH
                                    115 	.globl _DPL
                                    116 	.globl _SP
                                    117 	.globl _P0
                                    118 	.globl _sharedBuffer
                                    119 	.globl _tail
                                    120 	.globl _head
                                    121 	.globl _empty
                                    122 	.globl _full
                                    123 	.globl _mutex
                                    124 	.globl _charBuffer
                                    125 ;--------------------------------------------------------
                                    126 ; special function registers
                                    127 ;--------------------------------------------------------
                                    128 	.area RSEG    (ABS,DATA)
      000000                        129 	.org 0x0000
                           000080   130 _P0	=	0x0080
                           000081   131 _SP	=	0x0081
                           000082   132 _DPL	=	0x0082
                           000083   133 _DPH	=	0x0083
                           000087   134 _PCON	=	0x0087
                           000088   135 _TCON	=	0x0088
                           000089   136 _TMOD	=	0x0089
                           00008A   137 _TL0	=	0x008a
                           00008B   138 _TL1	=	0x008b
                           00008C   139 _TH0	=	0x008c
                           00008D   140 _TH1	=	0x008d
                           000090   141 _P1	=	0x0090
                           000098   142 _SCON	=	0x0098
                           000099   143 _SBUF	=	0x0099
                           0000A0   144 _P2	=	0x00a0
                           0000A8   145 _IE	=	0x00a8
                           0000B0   146 _P3	=	0x00b0
                           0000B8   147 _IP	=	0x00b8
                           0000D0   148 _PSW	=	0x00d0
                           0000E0   149 _ACC	=	0x00e0
                           0000F0   150 _B	=	0x00f0
                                    151 ;--------------------------------------------------------
                                    152 ; special function bits
                                    153 ;--------------------------------------------------------
                                    154 	.area RSEG    (ABS,DATA)
      000000                        155 	.org 0x0000
                           000080   156 _P0_0	=	0x0080
                           000081   157 _P0_1	=	0x0081
                           000082   158 _P0_2	=	0x0082
                           000083   159 _P0_3	=	0x0083
                           000084   160 _P0_4	=	0x0084
                           000085   161 _P0_5	=	0x0085
                           000086   162 _P0_6	=	0x0086
                           000087   163 _P0_7	=	0x0087
                           000088   164 _IT0	=	0x0088
                           000089   165 _IE0	=	0x0089
                           00008A   166 _IT1	=	0x008a
                           00008B   167 _IE1	=	0x008b
                           00008C   168 _TR0	=	0x008c
                           00008D   169 _TF0	=	0x008d
                           00008E   170 _TR1	=	0x008e
                           00008F   171 _TF1	=	0x008f
                           000090   172 _P1_0	=	0x0090
                           000091   173 _P1_1	=	0x0091
                           000092   174 _P1_2	=	0x0092
                           000093   175 _P1_3	=	0x0093
                           000094   176 _P1_4	=	0x0094
                           000095   177 _P1_5	=	0x0095
                           000096   178 _P1_6	=	0x0096
                           000097   179 _P1_7	=	0x0097
                           000098   180 _RI	=	0x0098
                           000099   181 _TI	=	0x0099
                           00009A   182 _RB8	=	0x009a
                           00009B   183 _TB8	=	0x009b
                           00009C   184 _REN	=	0x009c
                           00009D   185 _SM2	=	0x009d
                           00009E   186 _SM1	=	0x009e
                           00009F   187 _SM0	=	0x009f
                           0000A0   188 _P2_0	=	0x00a0
                           0000A1   189 _P2_1	=	0x00a1
                           0000A2   190 _P2_2	=	0x00a2
                           0000A3   191 _P2_3	=	0x00a3
                           0000A4   192 _P2_4	=	0x00a4
                           0000A5   193 _P2_5	=	0x00a5
                           0000A6   194 _P2_6	=	0x00a6
                           0000A7   195 _P2_7	=	0x00a7
                           0000A8   196 _EX0	=	0x00a8
                           0000A9   197 _ET0	=	0x00a9
                           0000AA   198 _EX1	=	0x00aa
                           0000AB   199 _ET1	=	0x00ab
                           0000AC   200 _ES	=	0x00ac
                           0000AF   201 _EA	=	0x00af
                           0000B0   202 _P3_0	=	0x00b0
                           0000B1   203 _P3_1	=	0x00b1
                           0000B2   204 _P3_2	=	0x00b2
                           0000B3   205 _P3_3	=	0x00b3
                           0000B4   206 _P3_4	=	0x00b4
                           0000B5   207 _P3_5	=	0x00b5
                           0000B6   208 _P3_6	=	0x00b6
                           0000B7   209 _P3_7	=	0x00b7
                           0000B0   210 _RXD	=	0x00b0
                           0000B1   211 _TXD	=	0x00b1
                           0000B2   212 _INT0	=	0x00b2
                           0000B3   213 _INT1	=	0x00b3
                           0000B4   214 _T0	=	0x00b4
                           0000B5   215 _T1	=	0x00b5
                           0000B6   216 _WR	=	0x00b6
                           0000B7   217 _RD	=	0x00b7
                           0000B8   218 _PX0	=	0x00b8
                           0000B9   219 _PT0	=	0x00b9
                           0000BA   220 _PX1	=	0x00ba
                           0000BB   221 _PT1	=	0x00bb
                           0000BC   222 _PS	=	0x00bc
                           0000D0   223 _P	=	0x00d0
                           0000D1   224 _F1	=	0x00d1
                           0000D2   225 _OV	=	0x00d2
                           0000D3   226 _RS0	=	0x00d3
                           0000D4   227 _RS1	=	0x00d4
                           0000D5   228 _F0	=	0x00d5
                           0000D6   229 _AC	=	0x00d6
                           0000D7   230 _CY	=	0x00d7
                                    231 ;--------------------------------------------------------
                                    232 ; overlayable register banks
                                    233 ;--------------------------------------------------------
                                    234 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        235 	.ds 8
                                    236 ;--------------------------------------------------------
                                    237 ; internal ram data
                                    238 ;--------------------------------------------------------
                                    239 	.area DSEG    (DATA)
                           000035   240 _charBuffer	=	0x0035
                           000025   241 _mutex	=	0x0025
                           000026   242 _full	=	0x0026
                           000027   243 _empty	=	0x0027
                           00003A   244 _head	=	0x003a
                           00003B   245 _tail	=	0x003b
                           00003D   246 _sharedBuffer	=	0x003d
                                    247 ;--------------------------------------------------------
                                    248 ; overlayable items in internal ram
                                    249 ;--------------------------------------------------------
                                    250 	.area	OSEG    (OVR,DATA)
      000008                        251 _SemaphoreCreate_PARM_2:
      000008                        252 	.ds 1
                                    253 ;--------------------------------------------------------
                                    254 ; Stack segment in internal ram
                                    255 ;--------------------------------------------------------
                                    256 	.area SSEG
      000009                        257 __start__stack:
      000009                        258 	.ds	1
                                    259 
                                    260 ;--------------------------------------------------------
                                    261 ; indirectly addressable internal ram data
                                    262 ;--------------------------------------------------------
                                    263 	.area ISEG    (DATA)
                                    264 ;--------------------------------------------------------
                                    265 ; absolute internal ram data
                                    266 ;--------------------------------------------------------
                                    267 	.area IABS    (ABS,DATA)
                                    268 	.area IABS    (ABS,DATA)
                                    269 ;--------------------------------------------------------
                                    270 ; bit data
                                    271 ;--------------------------------------------------------
                                    272 	.area BSEG    (BIT)
                                    273 ;--------------------------------------------------------
                                    274 ; paged external ram data
                                    275 ;--------------------------------------------------------
                                    276 	.area PSEG    (PAG,XDATA)
                                    277 ;--------------------------------------------------------
                                    278 ; uninitialized external ram data
                                    279 ;--------------------------------------------------------
                                    280 	.area XSEG    (XDATA)
                                    281 ;--------------------------------------------------------
                                    282 ; absolute external ram data
                                    283 ;--------------------------------------------------------
                                    284 	.area XABS    (ABS,XDATA)
                                    285 ;--------------------------------------------------------
                                    286 ; initialized external ram data
                                    287 ;--------------------------------------------------------
                                    288 	.area XISEG   (XDATA)
                                    289 	.area HOME    (CODE)
                                    290 	.area GSINIT0 (CODE)
                                    291 	.area GSINIT1 (CODE)
                                    292 	.area GSINIT2 (CODE)
                                    293 	.area GSINIT3 (CODE)
                                    294 	.area GSINIT4 (CODE)
                                    295 	.area GSINIT5 (CODE)
                                    296 	.area GSINIT  (CODE)
                                    297 	.area GSFINAL (CODE)
                                    298 	.area CSEG    (CODE)
                                    299 ;--------------------------------------------------------
                                    300 ; interrupt vector
                                    301 ;--------------------------------------------------------
                                    302 	.area HOME    (CODE)
      000000                        303 __interrupt_vect:
      000000 02 00 F4         [24]  304 	ljmp	__sdcc_gsinit_startup
      000003 32               [24]  305 	reti
      000004                        306 	.ds	7
      00000B 02 00 FB         [24]  307 	ljmp	_timer0_ISR
                                    308 ;--------------------------------------------------------
                                    309 ; global & static initialisations
                                    310 ;--------------------------------------------------------
                                    311 	.area HOME    (CODE)
                                    312 	.area GSINIT  (CODE)
                                    313 	.area GSFINAL (CODE)
                                    314 	.area GSINIT  (CODE)
                                    315 	.globl __sdcc_gsinit_startup
                                    316 	.globl __sdcc_program_startup
                                    317 	.globl __start__stack
                                    318 	.globl __mcs51_genXINIT
                                    319 	.globl __mcs51_genXRAMCLEAR
                                    320 	.globl __mcs51_genRAMCLEAR
                                    321 	.area GSFINAL (CODE)
      000011 02 00 0E         [24]  322 	ljmp	__sdcc_program_startup
                                    323 ;--------------------------------------------------------
                                    324 ; Home
                                    325 ;--------------------------------------------------------
                                    326 	.area HOME    (CODE)
                                    327 	.area HOME    (CODE)
      00000E                        328 __sdcc_program_startup:
      00000E 02 00 B8         [24]  329 	ljmp	_main
                                    330 ;	return from main will return to caller
                                    331 ;--------------------------------------------------------
                                    332 ; code
                                    333 ;--------------------------------------------------------
                                    334 	.area CSEG    (CODE)
                                    335 ;------------------------------------------------------------
                                    336 ;Allocation info for local variables in function 'SemaphoreCreate'
                                    337 ;------------------------------------------------------------
                                    338 ;n                         Allocated with name '_SemaphoreCreate_PARM_2'
                                    339 ;s                         Allocated to registers r5 r6 r7 
                                    340 ;------------------------------------------------------------
                                    341 ;	testpreempt.c:55: void SemaphoreCreate(char *s, char n){ 
                                    342 ;	-----------------------------------------
                                    343 ;	 function SemaphoreCreate
                                    344 ;	-----------------------------------------
      000014                        345 _SemaphoreCreate:
                           000007   346 	ar7 = 0x07
                           000006   347 	ar6 = 0x06
                           000005   348 	ar5 = 0x05
                           000004   349 	ar4 = 0x04
                           000003   350 	ar3 = 0x03
                           000002   351 	ar2 = 0x02
                           000001   352 	ar1 = 0x01
                           000000   353 	ar0 = 0x00
      000014 AD 82            [24]  354 	mov	r5, dpl
      000016 AE 83            [24]  355 	mov	r6, dph
      000018 AF F0            [24]  356 	mov	r7, b
                                    357 ;	testpreempt.c:56: EA = 0;
                                    358 ;	assignBit
      00001A C2 AF            [12]  359 	clr	_EA
                                    360 ;	testpreempt.c:57: *s = n; 
      00001C 8D 82            [24]  361 	mov	dpl,r5
      00001E 8E 83            [24]  362 	mov	dph,r6
      000020 8F F0            [24]  363 	mov	b,r7
      000022 E5 08            [12]  364 	mov	a,_SemaphoreCreate_PARM_2
      000024 12 04 A8         [24]  365 	lcall	__gptrput
                                    366 ;	testpreempt.c:58: EA = 1;
                                    367 ;	assignBit
      000027 D2 AF            [12]  368 	setb	_EA
                                    369 ;	testpreempt.c:59: }
      000029 22               [24]  370 	ret
                                    371 ;------------------------------------------------------------
                                    372 ;Allocation info for local variables in function 'Producer'
                                    373 ;------------------------------------------------------------
                                    374 ;	testpreempt.c:66: void Producer(void)
                                    375 ;	-----------------------------------------
                                    376 ;	 function Producer
                                    377 ;	-----------------------------------------
      00002A                        378 _Producer:
                                    379 ;	testpreempt.c:73: EA = 0;
                                    380 ;	assignBit
      00002A C2 AF            [12]  381 	clr	_EA
                                    382 ;	testpreempt.c:74: charBuffer = 'A'-1;
      00002C 75 35 40         [24]  383 	mov	_charBuffer,#0x40
                                    384 ;	testpreempt.c:75: EA = 1;
                                    385 ;	assignBit
      00002F D2 AF            [12]  386 	setb	_EA
                                    387 ;	testpreempt.c:77: while (1)
      000031                        388 00107$:
                                    389 ;	testpreempt.c:82: SemaphoreWait(empty);
      000031                        390 0$:
      000031 85 27 E0         [24]  391 	MOV ACC, _empty 
      000034 60 FB            [24]  392 	JZ 0$ 
      000036 20 E7 F8         [24]  393 	JB ACC.7, 0$ 
      000039 15 27            [12]  394 	dec _empty 
                                    395 ;	testpreempt.c:83: SemaphoreWait(mutex);
      00003B                        396 1$:
      00003B 85 25 E0         [24]  397 	MOV ACC, _mutex 
      00003E 60 FB            [24]  398 	JZ 1$ 
      000040 20 E7 F8         [24]  399 	JB ACC.7, 1$ 
      000043 15 25            [12]  400 	dec _mutex 
                                    401 ;	testpreempt.c:84: EA = 0;
                                    402 ;	assignBit
      000045 C2 AF            [12]  403 	clr	_EA
                                    404 ;	testpreempt.c:86: if(charBuffer == 'Z'){
      000047 74 5A            [12]  405 	mov	a,#0x5a
      000049 B5 35 05         [24]  406 	cjne	a,_charBuffer,00102$
                                    407 ;	testpreempt.c:87: charBuffer = 'A';
      00004C 75 35 41         [24]  408 	mov	_charBuffer,#0x41
      00004F 80 05            [24]  409 	sjmp	00103$
      000051                        410 00102$:
                                    411 ;	testpreempt.c:90: charBuffer += 1;
      000051 E5 35            [12]  412 	mov	a,_charBuffer
      000053 04               [12]  413 	inc	a
      000054 F5 35            [12]  414 	mov	_charBuffer,a
      000056                        415 00103$:
                                    416 ;	testpreempt.c:92: sharedBuffer[tail] = charBuffer;
      000056 E5 3B            [12]  417 	mov	a,_tail
      000058 24 3D            [12]  418 	add	a, #_sharedBuffer
      00005A F8               [12]  419 	mov	r0,a
      00005B A6 35            [24]  420 	mov	@r0,_charBuffer
                                    421 ;	testpreempt.c:93: tail += 1;
      00005D E5 3B            [12]  422 	mov	a,_tail
      00005F FF               [12]  423 	mov	r7,a
      000060 04               [12]  424 	inc	a
      000061 F5 3B            [12]  425 	mov	_tail,a
                                    426 ;	testpreempt.c:94: if(tail == 3){
      000063 74 03            [12]  427 	mov	a,#0x03
      000065 B5 3B 03         [24]  428 	cjne	a,_tail,00105$
                                    429 ;	testpreempt.c:95: tail = 0;
      000068 75 3B 00         [24]  430 	mov	_tail,#0x00
      00006B                        431 00105$:
                                    432 ;	testpreempt.c:101: EA = 1;
                                    433 ;	assignBit
      00006B D2 AF            [12]  434 	setb	_EA
                                    435 ;	testpreempt.c:102: SemaphoreSignal(mutex);
      00006D 05 25            [12]  436 	INC _mutex 
                                    437 ;	testpreempt.c:103: SemaphoreSignal(full);
      00006F 05 26            [12]  438 	INC _full 
                                    439 ;	testpreempt.c:105: }
      000071 80 BE            [24]  440 	sjmp	00107$
                                    441 ;------------------------------------------------------------
                                    442 ;Allocation info for local variables in function 'Consumer'
                                    443 ;------------------------------------------------------------
                                    444 ;	testpreempt.c:112: void Consumer(void)
                                    445 ;	-----------------------------------------
                                    446 ;	 function Consumer
                                    447 ;	-----------------------------------------
      000073                        448 _Consumer:
                                    449 ;	testpreempt.c:118: TMOD |= 0x20;
      000073 43 89 20         [24]  450 	orl	_TMOD,#0x20
                                    451 ;	testpreempt.c:119: TH1 = (char)-6;
      000076 75 8D FA         [24]  452 	mov	_TH1,#0xfa
                                    453 ;	testpreempt.c:120: SCON = 0x50;
      000079 75 98 50         [24]  454 	mov	_SCON,#0x50
                                    455 ;	testpreempt.c:121: TR1 = 1;
                                    456 ;	assignBit
      00007C D2 8E            [12]  457 	setb	_TR1
                                    458 ;	testpreempt.c:122: TI = 1;
                                    459 ;	assignBit
      00007E D2 99            [12]  460 	setb	_TI
                                    461 ;	testpreempt.c:124: while (1)
      000080                        462 00107$:
                                    463 ;	testpreempt.c:134: SemaphoreWait(full);
      000080                        464 2$:
      000080 85 26 E0         [24]  465 	MOV ACC, _full 
      000083 60 FB            [24]  466 	JZ 2$ 
      000085 20 E7 F8         [24]  467 	JB ACC.7, 2$ 
      000088 15 26            [12]  468 	dec _full 
                                    469 ;	testpreempt.c:135: SemaphoreWait(mutex);
      00008A                        470 3$:
      00008A 85 25 E0         [24]  471 	MOV ACC, _mutex 
      00008D 60 FB            [24]  472 	JZ 3$ 
      00008F 20 E7 F8         [24]  473 	JB ACC.7, 3$ 
      000092 15 25            [12]  474 	dec _mutex 
                                    475 ;	testpreempt.c:136: EA = 0;
                                    476 ;	assignBit
      000094 C2 AF            [12]  477 	clr	_EA
                                    478 ;	testpreempt.c:138: while (!TI){
      000096                        479 00101$:
      000096 30 99 FD         [24]  480 	jnb	_TI,00101$
                                    481 ;	testpreempt.c:140: SBUF = sharedBuffer[head];
      000099 E5 3A            [12]  482 	mov	a,_head
      00009B 24 3D            [12]  483 	add	a, #_sharedBuffer
      00009D F9               [12]  484 	mov	r1,a
      00009E 87 99            [24]  485 	mov	_SBUF,@r1
                                    486 ;	testpreempt.c:141: TI = 0;
                                    487 ;	assignBit
      0000A0 C2 99            [12]  488 	clr	_TI
                                    489 ;	testpreempt.c:142: head += 1;
      0000A2 E5 3A            [12]  490 	mov	a,_head
      0000A4 FF               [12]  491 	mov	r7,a
      0000A5 04               [12]  492 	inc	a
      0000A6 F5 3A            [12]  493 	mov	_head,a
                                    494 ;	testpreempt.c:143: if(head == 3){
      0000A8 74 03            [12]  495 	mov	a,#0x03
      0000AA B5 3A 03         [24]  496 	cjne	a,_head,00105$
                                    497 ;	testpreempt.c:144: head = 0;
      0000AD 75 3A 00         [24]  498 	mov	_head,#0x00
      0000B0                        499 00105$:
                                    500 ;	testpreempt.c:150: EA = 1;
                                    501 ;	assignBit
      0000B0 D2 AF            [12]  502 	setb	_EA
                                    503 ;	testpreempt.c:151: SemaphoreSignal(mutex);
      0000B2 05 25            [12]  504 	INC _mutex 
                                    505 ;	testpreempt.c:152: SemaphoreSignal(empty);
      0000B4 05 27            [12]  506 	INC _empty 
                                    507 ;	testpreempt.c:154: }
      0000B6 80 C8            [24]  508 	sjmp	00107$
                                    509 ;------------------------------------------------------------
                                    510 ;Allocation info for local variables in function 'main'
                                    511 ;------------------------------------------------------------
                                    512 ;	testpreempt.c:161: void main(void)
                                    513 ;	-----------------------------------------
                                    514 ;	 function main
                                    515 ;	-----------------------------------------
      0000B8                        516 _main:
                                    517 ;	testpreempt.c:168: SemaphoreCreate(&mutex, 1);
      0000B8 75 08 01         [24]  518 	mov	_SemaphoreCreate_PARM_2,#0x01
      0000BB 90 00 25         [24]  519 	mov	dptr,#_mutex
      0000BE 75 F0 40         [24]  520 	mov	b, #0x40
      0000C1 12 00 14         [24]  521 	lcall	_SemaphoreCreate
                                    522 ;	testpreempt.c:169: SemaphoreCreate(&full, 0);
      0000C4 75 08 00         [24]  523 	mov	_SemaphoreCreate_PARM_2,#0x00
      0000C7 90 00 26         [24]  524 	mov	dptr,#_full
      0000CA 75 F0 40         [24]  525 	mov	b, #0x40
      0000CD 12 00 14         [24]  526 	lcall	_SemaphoreCreate
                                    527 ;	testpreempt.c:170: SemaphoreCreate(&empty, 3);
      0000D0 75 08 03         [24]  528 	mov	_SemaphoreCreate_PARM_2,#0x03
      0000D3 90 00 27         [24]  529 	mov	dptr,#_empty
      0000D6 75 F0 40         [24]  530 	mov	b, #0x40
      0000D9 12 00 14         [24]  531 	lcall	_SemaphoreCreate
                                    532 ;	testpreempt.c:171: sharedBuffer[0] = ' ';
      0000DC 75 3D 20         [24]  533 	mov	_sharedBuffer,#0x20
                                    534 ;	testpreempt.c:172: sharedBuffer[1] = ' ';
      0000DF 75 3E 20         [24]  535 	mov	(_sharedBuffer + 0x0001),#0x20
                                    536 ;	testpreempt.c:173: sharedBuffer[2] = ' ';
      0000E2 75 3F 20         [24]  537 	mov	(_sharedBuffer + 0x0002),#0x20
                                    538 ;	testpreempt.c:174: head = 0;
      0000E5 75 3A 00         [24]  539 	mov	_head,#0x00
                                    540 ;	testpreempt.c:175: tail = 0;
      0000E8 75 3B 00         [24]  541 	mov	_tail,#0x00
                                    542 ;	testpreempt.c:183: ThreadCreate(Producer);
      0000EB 90 00 2A         [24]  543 	mov	dptr,#_Producer
      0000EE 12 01 53         [24]  544 	lcall	_ThreadCreate
                                    545 ;	testpreempt.c:184: Consumer();
                                    546 ;	testpreempt.c:185: }
      0000F1 02 00 73         [24]  547 	ljmp	_Consumer
                                    548 ;------------------------------------------------------------
                                    549 ;Allocation info for local variables in function '_sdcc_gsinit_startup'
                                    550 ;------------------------------------------------------------
                                    551 ;	testpreempt.c:187: void _sdcc_gsinit_startup(void)
                                    552 ;	-----------------------------------------
                                    553 ;	 function _sdcc_gsinit_startup
                                    554 ;	-----------------------------------------
      0000F4                        555 __sdcc_gsinit_startup:
                                    556 ;	testpreempt.c:191: __endasm;
      0000F4 02 00 FF         [24]  557 	ljmp	_Bootstrap
                                    558 ;	testpreempt.c:192: }
      0000F7 22               [24]  559 	ret
                                    560 ;------------------------------------------------------------
                                    561 ;Allocation info for local variables in function '_mcs51_genRAMCLEAR'
                                    562 ;------------------------------------------------------------
                                    563 ;	testpreempt.c:194: void _mcs51_genRAMCLEAR(void) {}
                                    564 ;	-----------------------------------------
                                    565 ;	 function _mcs51_genRAMCLEAR
                                    566 ;	-----------------------------------------
      0000F8                        567 __mcs51_genRAMCLEAR:
      0000F8 22               [24]  568 	ret
                                    569 ;------------------------------------------------------------
                                    570 ;Allocation info for local variables in function '_mcs51_genXINIT'
                                    571 ;------------------------------------------------------------
                                    572 ;	testpreempt.c:195: void _mcs51_genXINIT(void) {}
                                    573 ;	-----------------------------------------
                                    574 ;	 function _mcs51_genXINIT
                                    575 ;	-----------------------------------------
      0000F9                        576 __mcs51_genXINIT:
      0000F9 22               [24]  577 	ret
                                    578 ;------------------------------------------------------------
                                    579 ;Allocation info for local variables in function '_mcs51_genXRAMCLEAR'
                                    580 ;------------------------------------------------------------
                                    581 ;	testpreempt.c:196: void _mcs51_genXRAMCLEAR(void) {}
                                    582 ;	-----------------------------------------
                                    583 ;	 function _mcs51_genXRAMCLEAR
                                    584 ;	-----------------------------------------
      0000FA                        585 __mcs51_genXRAMCLEAR:
      0000FA 22               [24]  586 	ret
                                    587 ;------------------------------------------------------------
                                    588 ;Allocation info for local variables in function 'timer0_ISR'
                                    589 ;------------------------------------------------------------
                                    590 ;	testpreempt.c:197: void timer0_ISR(void) __interrupt(1) {
                                    591 ;	-----------------------------------------
                                    592 ;	 function timer0_ISR
                                    593 ;	-----------------------------------------
      0000FB                        594 _timer0_ISR:
                                    595 ;	testpreempt.c:200: __endasm;
      0000FB 02 03 CE         [24]  596 	ljmp	_myTimer0Handler
                                    597 ;	testpreempt.c:201: }
      0000FE 32               [24]  598 	reti
                                    599 ;	eliminated unneeded mov psw,# (no regs used in bank)
                                    600 ;	eliminated unneeded push/pop not_psw
                                    601 ;	eliminated unneeded push/pop dpl
                                    602 ;	eliminated unneeded push/pop dph
                                    603 ;	eliminated unneeded push/pop b
                                    604 ;	eliminated unneeded push/pop acc
                                    605 	.area CSEG    (CODE)
                                    606 	.area CONST   (CODE)
                                    607 	.area XINIT   (CODE)
                                    608 	.area CABS    (ABS,CODE)
